# 🛵 Système de Livraison Redis Pub/Sub

## 📋 Description

Ce projet implémente un **Proof of Concept (POC)** d'un système de livraison de repas utilisant **Redis Pub/Sub** pour simuler le scénario UberEats. Le système permet à un manager de publier des annonces de livraison et à des livreurs de manifester leur intérêt, avec une sélection automatique du livreur le plus approprié.

## 🎯 Objectifs

- **Modéliser** le flux de communication asynchrone entre manager et livreurs
- **Implémenter** deux approches différentes de gestion des réponses
- **Démontrer** l'utilisation de Redis Pub/Sub pour la communication temps réel
- **Simuler** un système de livraison complet avec données réelles

## 🏗️ Architecture

### Composants Principaux

1. **Manager** (`manager.py`) - Émetteur d'annonces et sélecteur de livreurs
2. **DeliveryPerson** (`delivery_person.py`) - Livreurs individuels
3. **DataLoader** (`data_loader.py`) - Gestion des données CSV
4. **Models** (`models.py`) - Modèles de données
5. **Demo** (`demo.py`) - Script de démonstration

### Channels Redis

```python
CHANNELS = {
    'ORDER_ANNOUNCEMENT': 'order:announcement',      # Annonces de commandes
    'DELIVERY_RESPONSE': 'delivery:response',        # Réponses des livreurs
    'DELIVERY_SELECTION': 'delivery:selection',      # Sélection du livreur
    'DELIVERY_NOTIFICATION': 'delivery:notification' # Notifications finales
}
```

## 🚀 Installation et Configuration

### Prérequis

- Python 3.8+
- Redis Server
- Les fichiers CSV dans le dossier `Redis/`

### Installation

1. **Cloner le projet**
```bash
cd "/home/student/905/12112504/Bureau/Mes_Montages/12112504/Projet DB"
```

2. **Installer les dépendances**
```bash
pip install -r requirements.txt
```

3. **Démarrer Redis**
```bash
redis-server
```

4. **Configurer l'environnement** (optionnel)
```bash
cp env_example.txt .env
# Modifier les paramètres Redis si nécessaire
```

## 🎮 Utilisation

### Démonstration Automatique

```bash
python demo.py
# Choisir l'option 1 pour la démonstration automatique
```

### Mode Interactif

```bash
python demo.py
# Choisir l'option 2 pour le mode interactif
# Commandes disponibles:
#   'a' - Créer une nouvelle annonce
#   's' - Afficher les statistiques
#   'q' - Quitter
```

## 📊 Flux de Données

### 1. Création d'une Annonce

```mermaid
graph TD
    A[Manager] --> B[Créer Commande Aléatoire]
    B --> C[Calculer Distance & Compensation]
    C --> D[Publier sur order:announcement]
    D --> E[Livreurs Écoutent]
```

### 2. Réponse des Livreurs

```mermaid
graph TD
    A[Livreur Reçoit Annonce] --> B{Intéressé?}
    B -->|Oui| C[Calculer Temps d'Arrivée]
    B -->|Non| D[Ignorer]
    C --> E[Publier sur delivery:response]
    E --> F[Manager Traite Réponse]
```

### 3. Sélection et Notification

```mermaid
graph TD
    A[Manager Reçoit Réponses] --> B[Sélectionner Premier Intéressé]
    B --> C[Publier Sélection]
    C --> D[Notifier Tous les Livreurs]
    D --> E[Livreur Sélectionné Confirmé]
    D --> F[Autres Livreurs Informés]
```

## 🗂️ Structure des Données

### Restaurant
```python
@dataclass
class Restaurant:
    id: int
    name: str
    address: str
    lat: float
    lng: float
    category: str
    price_range: str
```

### DeliveryAnnouncement
```python
@dataclass
class DeliveryAnnouncement:
    announcement_id: str
    order: DeliveryOrder
    pickup_location: str
    delivery_location: str
    compensation: float
    estimated_distance: float
    created_at: datetime
```

### DeliveryResponse
```python
@dataclass
class DeliveryResponse:
    response_id: str
    delivery_person_id: str
    delivery_person_name: str
    announcement_id: str
    is_interested: bool
    estimated_arrival_time: Optional[int]
    current_location: Optional[str]
    response_time: Optional[datetime]
```

## 🔧 Configuration

### Paramètres de Simulation

```python
SIMULATION_CONFIG = {
    'delivery_radius_km': 5.0,  # Rayon de livraison en km
    'base_delivery_fee': 3.50,  # Frais de base de livraison
    'response_timeout': 30,     # Timeout pour les réponses (secondes)
    'max_delivery_attempts': 3  # Nombre max de tentatives de livraison
}
```

### Comportement des Livreurs

- **Probabilité d'intérêt**: 30-90% (aléatoire)
- **Délai de réponse**: 1-5 secondes
- **Facteurs de décision**: Distance, compensation, probabilité de base

## 📈 Statistiques

Le système collecte automatiquement des statistiques pour chaque livreur :

- Nombre d'annonces reçues
- Nombre de réponses envoyées
- Nombre de sélections reçues
- Gains totaux
- Taux de réponse global

## 🧪 Tests et Démonstration

### Scénario de Test

1. **5 livreurs** sont créés avec des profils différents
2. **3 annonces** sont publiées avec un intervalle de 3 secondes
3. Chaque livreur **évalue** l'annonce selon ses critères
4. Le **premier livreur intéressé** est sélectionné
5. **Tous les livreurs** sont notifiés du résultat

### Exemple de Sortie

```
📢 Annonce publiée: 123e4567-e89b-12d3-a456-426614174000
   Restaurant: PJ Fresh (224 Daniel Payne Drive)
   Distance: 2.34 km
   Compensation: 4.67€

📨 Réponse reçue de Alex Martin: ✅ Intéressé
📨 Réponse reçue de Sarah Johnson: ✅ Intéressé
🎯 Livreur sélectionné: Alex Martin

📢 Notification envoyée à Alex Martin: ✅ SÉLECTIONNÉ
📢 Notification envoyée à Sarah Johnson: ❌ Non sélectionné
```

## 🔍 Points Techniques

### Redis Pub/Sub

- **Channels dédiés** pour chaque type de message
- **Décodage automatique** des messages JSON
- **Gestion des erreurs** et timeouts
- **Threads séparés** pour l'écoute

### Gestion Asynchrone

- **Threading** pour l'écoute des messages
- **Signaux** pour l'arrêt propre
- **Timeouts** pour éviter les blocages
- **Nettoyage automatique** des ressources

### Données Réelles

- **5000+ restaurants** de Birmingham, AL
- **445K+ items de menu** avec prix
- **Géolocalisation** précise (lat/lng)
- **Calcul de distance** avec formule de Haversine

## 🚧 Améliorations Possibles

1. **Stratégies de sélection** plus sophistiquées
2. **Système de réputation** des livreurs
3. **Géolocalisation en temps réel**
4. **Interface web** pour le monitoring
5. **Persistance** des données en base
6. **Tests unitaires** complets
7. **Logging** structuré
8. **Métriques** de performance

## 📚 Références

- [Redis Pub/Sub Documentation](https://redis.io/docs/latest/develop/pubsub/)
- [Python Redis Client](https://redis-py.readthedocs.io/)
- [Pandas Documentation](https://pandas.pydata.org/docs/)

## 👥 Auteur

Projet développé dans le cadre d'un cours de bases de données, implémentant un système de livraison de repas avec Redis Pub/Sub.

---

*Ce projet démontre l'utilisation efficace de Redis Pub/Sub pour la communication asynchrone en temps réel dans un système distribué.*
