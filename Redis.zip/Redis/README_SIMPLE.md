# 🛵 Système de Livraison Redis - Version Simplifiée

## 📋 Description

Version simplifiée du système de livraison Redis Pub/Sub avec seulement **2 fichiers** :
- `manager_redis.py` - Le manager qui publie les annonces
- `livreur_redis.py` - Les livreurs qui répondent aux annonces

## 🚀 Utilisation Rapide

### 1. Installer les dépendances
```bash
pip3 install -r requirements.txt
```

### 2. Démarrer Redis
```bash
redis-server
```

### 3. Lancer le Manager (Terminal 1)
```bash
python3 manager_redis.py
```
Commandes disponibles :
- `a` - Créer une nouvelle annonce
- `s` - Afficher les statistiques
- `q` - Quitter

### 4. Lancer des Livreurs (Terminal 2, 3, 4...)
```bash
python3 livreur_redis.py
```
Entrez votre nom de livreur, puis :
- `s` - Afficher les statistiques
- `q` - Quitter

## 🎯 Scénario de Test

1. **Démarrez Redis** dans un terminal
2. **Démarrez le Manager** dans un terminal
3. **Démarrez 2-3 Livreurs** dans d'autres terminaux
4. **Créez une annonce** avec la commande `a` dans le manager
5. **Observez** les livreurs recevoir l'annonce et répondre
6. **Voyez** la sélection automatique du premier livreur intéressé

## 📊 Exemple de Sortie

### Manager
```
📢 Annonce publiée: 123e4567-e89b-12d3-a456-426614174000
   Restaurant: PJ Fresh (224 Daniel Payne Drive)
   Distance: 2.34 km
   Compensation: 4.67€

📨 Réponse reçue de Alex: ✅ Intéressé
📨 Réponse reçue de Sarah: ✅ Intéressé
🎯 Livreur sélectionné: Alex
```

### Livreur
```
📢 Alex a reçu une annonce:
   Restaurant: PJ Fresh (224 Daniel Payne Drive)
   Distance: 2.34 km
   Compensation: 4.67€
🤔 Alex est intéressé par cette livraison
📤 Alex a envoyé sa réponse: ✅ Intéressé
🎉 Alex a été SÉLECTIONNÉ pour la livraison!
```

## 🔧 Fonctionnalités

- ✅ **Données réelles** de 5000+ restaurants de Birmingham, AL
- ✅ **Géolocalisation** avec calcul de distances
- ✅ **Comportement intelligent** des livreurs (probabilité d'intérêt)
- ✅ **Sélection automatique** premier arrivé, premier servi
- ✅ **Notifications** à tous les livreurs
- ✅ **Statistiques** en temps réel
- ✅ **Compatible Python 3.8+**

## 🎮 Commandes

### Manager
- `a` - Créer une nouvelle annonce de livraison
- `s` - Afficher les statistiques (annonces actives, réponses)
- `q` - Quitter le programme

### Livreur
- `s` - Afficher les statistiques personnelles
- `q` - Quitter le programme

## 🏗️ Architecture

```
Manager (manager_redis.py)
    ↓ Publie annonces
Redis Pub/Sub
    ↓ Distribue aux livreurs
Livreurs (livreur_redis.py)
    ↓ Envoient réponses
Redis Pub/Sub
    ↓ Retourne au manager
Manager sélectionne et notifie
```

## 📈 Statistiques

Chaque livreur collecte :
- Nombre d'annonces reçues
- Nombre de réponses envoyées
- Nombre de sélections reçues
- Gains totaux
- Probabilité d'intérêt

## 🚧 Dépannage

### Redis ne démarre pas
```bash
# Vérifier si Redis est déjà en cours
ps aux | grep redis

# Tuer les processus Redis existants
sudo pkill redis-server

# Redémarrer Redis
redis-server
```

### Erreur de connexion Redis
- Vérifiez que Redis est démarré : `redis-cli ping`
- Vérifiez la configuration dans les fichiers Python

### Erreur d'import
```bash
pip3 install redis pandas
```

## 🎯 Avantages de cette Version

1. **Simplicité** - Seulement 2 fichiers
2. **Facilité d'utilisation** - Un terminal par composant
3. **Compatibilité** - Python 3.8+
4. **Données réelles** - Restaurants et menus de Birmingham
5. **Comportement réaliste** - Livreurs avec personnalités différentes
6. **Monitoring** - Statistiques intégrées

---

*Système prêt à l'emploi pour démontrer Redis Pub/Sub !* 🚀
